package main;

public class Start {
public static void main(String[] args) {
		
		Main ma = new Main();
		
		ma.m();
		
		
		
		
		

		
	}
}
